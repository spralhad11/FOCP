width = 104.32
height = 15.654

area = width * height

message = f"The area of a rectangle with a width of {width} and a height of {height} is {area:.2f}."
print(message)
