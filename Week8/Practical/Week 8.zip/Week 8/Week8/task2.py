name = "John"
age = 25

message = f"{name:<15} - {age:10}"
print(message)
